var map
var osm_street   = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png'),
    dark  = L.tileLayer('https://cartodb-basemaps-{s}.global.ssl.fastly.net/dark_all/{z}/{x}/{y}.png'),
    googleSat = L.tileLayer('http://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}',{
                    maxZoom: 20,
                    subdomains:['mt0','mt1','mt2','mt3']
                });


 map = L.map('map', {
  center: [51.50345217816303, -0.08892059326171876],
  zoom: 13,
  attributionControl: false
});
var googlestreet   = L.tileLayer('http://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}',{
    maxZoom: 20,
    subdomains:['mt0','mt1','mt2','mt3']
    }).addTo(map)
    map.zoomControl.setPosition('bottomright');


    var geocoder=L.Control.geocoder({
      // defaultMarkGeocode: false,
        collapsed:false,
        position:"topright", 
        placeholder:"Search Any Address and press Enter...",
        queryParams: {"countrycodes": "US"},
        geocoder: new L.Control.Geocoder.Nominatim({
        geocodingQueryParams: {
            "countrycodes": "US"
            }
        })
      })
      geocoder.addTo(map);






// $('#legenddiv').css('visibility','hidden');



var furl2='https://arcgis.netl.doe.gov/server/rest/services/Hosted/CT_Coal_Closures_April2023_2/FeatureServer/23';
var CT_Coal_Closures_April2023=L.esri.featureLayer({
         url: furl2,
         opacity: 0.7,
         style: (feature) => {
             let style = {
                 fillColor: "red",
                 weight: 0.3,
                 opacity: 1,
                 color:"black",
                 dashArray: '2',
                 fillOpacity: 0.8
             };
             return style;
         }
     });






const marker = L.marker([51.5, -0.09]).addTo(map);
const marker2 = L.marker([51.51, -0.09]);
const marker3 = L.marker([51.52, -0.09]);
const polygon = L.polygon([[51.51, -0.1],[51.5, -0.08],[51.53, -0.07],[51.50, -0.06]], {color: '#FF0000'}).addTo(map);
const polygon2 = L.polygon([[51.51, -0.1],[51.5, -0.08],[51.53, -0.07],[51.50, -0.06]], {color: '#0122FF'}).addTo(map);

const mylines = [{
    "type": "LineString",
    "coordinates": [[-0.1,51.51], [-0.07,51.53]]
}, {
    "type": "LineString",
    "coordinates": [[-0.1,51.5], [-0.07,51.50]]
}];
const geojson = L.geoJSON(null).addTo(map);
geojson.addData(mylines);




var baseLayers = {
  "Google Street": googlestreet,
  "Google Satellite": googleSat,
  "OSM (Openstreetmap)": osm_street,
  "Dark": dark,
};
const overlays = [
  {name: 'Google Street', layer: googlestreet},
  {name: 'Google Satellite', layer: googleSat},
  {name: 'OSM (Openstreetmap)', layer: osm_street},
  {name: 'Dark', layer: dark},
  {name: 'Marker', layer: marker},
  {name: 'Marker2', layer: marker2},
  {name: 'polygon', layer: polygon},
  {name: 'polygon2', layer: polygon2},
  {name: 'geojson', layer: geojson}
];

const legend = L.multiControl(overlays, {position:'topright', label: '<b style="font-size: 15px;">Layer Controll</b>'}).addTo(map);









$("#about-btn").click(function() {
  $("#aboutModal").modal("show");
  $(".navbar-collapse.in").collapse("hide");
  return false;
});


$("#legend-btn").click(function() {
  $("#legendModal").modal("show");
  $(".navbar-collapse.in").collapse("hide");
  return false;
});

$("#login-btn").click(function() {
  $("#loginModal").modal("show");
  $(".navbar-collapse.in").collapse("hide");
  return false;
});

$("#list-btn").click(function() {
  animateSidebar();
  return false;
});

$("#nav-btn").click(function() {
  $(".navbar-collapse").collapse("toggle");
  return false;
});

$("#sidebar-toggle-btn").click(function() {
  animateSidebar();
  return false;
});

$("#sidebar-hide-btn").click(function() {
  animateSidebar();
  return false;
});

function animateSidebar() {
  $("#sidebar").animate({
    width: "toggle"
  }, 350, function() {
    map.invalidateSize();
  });
}

function sizeLayerControl() {
  $(".leaflet-control-layers").css("max-height", $("#map").height() - 50);
}

function clearHighlight() {
  highlight.clearLayers();
}

function sidebarClick(id) {
  var layer = markerClusters.getLayer(id);
  map.setView([layer.getLatLng().lat, layer.getLatLng().lng], 17);
  layer.fire("click");
  /* Hide sidebar and go to the map on small screens */
  if (document.body.clientWidth <= 767) {
    $("#sidebar").hide();
    map.invalidateSize();
  }
}

